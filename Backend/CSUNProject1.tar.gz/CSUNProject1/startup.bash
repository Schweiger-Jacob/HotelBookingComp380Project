#!/bin/bash
node /volume1/CSUNProject1/index.js
