const express = require('express')
const app = express()
var queryString = require('querystring');
const { Pool } = require('pg');

// npm install pg
// npm install express
// npm install pg pg-pool

const pool = new Pool({
	user: 'jacob',
	password: 'jacob999',
	host: '192.168.0.12',
	port: '49153',
	database: 'Hotel Booking Database',
	waitForConnections: true,
	max: 20, // maximum number of connections in the pool
	idleTimeoutMillis: 30000, // how long a client is allowed to remain idle before being closed
	connectionTimeoutMillis: 2000, // how long to wait for a connection to be established
});


const getAllUserInfo = (request, response) => {
	pool.query('SELECT user_id, name, date_of_birth, account_creation_date FROM users', (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows)
	})
}

const getUserInfo = (request, response) => {
	const userId = request.params.id;
	pool.query('SELECT user_id, name, date_of_birth, account_creation_date FROM users where user_id = $1', [userId], (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows[0])
	})
}

const getAllBookingData = (request, response) => {
	pool.query('SELECT booking_id, date, user_id, room_id  FROM bookings', (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows)
	})
}

const getBookingData = (request, response) => {
	const bookingId = request.params.id;
	pool.query('SELECT booking_id, date, user_id, room_id  FROM bookings where booking_id = $1', [bookingId], (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows[0])
	})
}

const getAllHotelData = (request, response) => {
	pool.query('SELECT hotel_id, name, number_of_rooms, address FROM hotels', (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows)
	})
}
const getHotelData = (request, response) => {
	const hotelId = request.params.id;
	pool.query('SELECT hotel_id, name, number_of_rooms, address FROM hotels where hotel_id = $1', [hotelId], (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows[0])
	})
}

const getAllRoomsData = (request, response) => {
	pool.query('SELECT room_id, room_price, room_number, hotel_id FROM rooms', (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows)
	})
}

const getRoomsData = (request, response) => {
	const roomId = request.params.id;
	pool.query('SELECT room_id, room_price, room_number, hotel_id FROM rooms where room_id = $1', [roomId], (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows[0])
	})
}


const createUser = (request, response) => {
	const { name, date_of_birth } = request.body
	pool.query("INSERT INTO users (user_id, name, date_of_birth, account_creation_date) VALUES (nextval('userid'),$1, $2, CURRENT_TIMESTAMP)", [name, date_of_birth], (error, results) => {
		if (error){
			throw error
		}
	})
	pool.query("select user_id::integer from users where name = $1 and date_of_birth = $2 order by user_id DESC limit 1",[name, date_of_birth], (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows[0])
	})
}

const createHotel = (request, response) => {
	const { name, numberOfRooms, address } = request.body
	pool.query("INSERT INTO hotels (hotel_id, name, number_of_rooms, address) VALUES (nextval('hotelid'),$1, $2, $3)", [name, numberOfRooms, address], (error, results) => {
		if (error){
			throw error
		}
	})	
	pool.query("select hotel_id::integer from hotels where name = $1 and number_of_rooms = $2 and address = $3 order by hotel_id DESC limit 1",[name, numberOfRooms, address], (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows[0])
	})
}

const createRoom = (request, response) => {
	const { roomPrice, roomNumber, hotelId } = request.body
	pool.query("INSERT INTO rooms (room_id, room_price, room_number, hotel_id) VALUES (nextval('roomid'),$1, $2, $3)", [roomPrice, roomNumber, hotelId], (error, results) => {
		if (error){
			throw error
		}
	})
	pool.query("select room_id::integer from rooms where room_price = $1 and room_number = $2 and hotel_id = $3 order by room_id DESC limit 1",[roomPrice, roomNumber, hotelId], (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows[0])
	})
}

const createBooking = (request, response) => {
	const { userId, roomId } = request.body
	pool.query("INSERT INTO bookings (booking_id, date, user_id, room_id) VALUES (nextval('bookingid'), CURRENT_TIMESTAMP, $1, $2)", [userId, roomId], (error, results) => {
		if (error){
			throw error
		}
	})
	pool.query("select booking_id::integer from bookings where user_id = $1 and room_id = $2 order by booking_id DESC limit 1", [userId, roomId], (error, results) => {
		if (error){
			throw error
		}
	response.status(200).json(results.rows[0])
	})
}



app.use(express.json());
	
app.get('/getuserdata', getAllUserInfo)
app.get('/getuserdata/:id', getUserInfo)
app.get('/getbookingdata', getAllBookingData)
app.get('/getbookingdata/:id', getBookingData)
app.get('/gethoteldata', getAllHotelData)
app.get('/gethoteldata/:id', getHotelData)
app.get('/getroomsdata', getAllRoomsData)
app.get('/getroomsdata/:id', getRoomsData)

app.post('/users', createUser)
app.post('/bookings', createBooking)
app.post('/hotel', createHotel)
app.post('/rooms', createRoom)

app.listen(3000, () => console.log('Example app listening on port 3000!'))
