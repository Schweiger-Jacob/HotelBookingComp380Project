#!/bin/bash
pkill -f "node /volume1/CSUNProject1/startup.bash"
